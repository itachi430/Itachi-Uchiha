const { colors } = require('../func/colors.js');
module.exports = (color, message) => console.log(colors.hex(color, message));